package org.spring_boot.gamestore.service;

public interface ISessionManagementService {

    public void removeSessionMessage();

}
