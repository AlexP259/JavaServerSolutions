package org.spring_boot.gamestore.service;

import org.spring_boot.gamestore.entity.Game;
import org.spring_boot.gamestore.entity.User;
import org.spring_boot.gamestore.entity.UsersEWallet;
import org.spring_boot.gamestore.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;


@Service
public class UserService implements IUserService{

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;


    @Override
    public User saveUser(User user) {
        String password = passwordEncoder.encode(user.getPassword());
        user.setPassword(password);
        user.setRole("ROLE_USER");
        user.seteWallet(new UsersEWallet());
        User newUser = userRepo.save(user);
        return newUser;
    }

    @Override
    public User saveAdmin(User user) {
        String password = passwordEncoder.encode(user.getPassword());
        user.setPassword(password);
        user.setRole("ROLE_ADMIN");
        User newUser = userRepo.save(user);
        return newUser;
    }

    @Override
    public List<User> getAllUsers() {
        return userRepo.findAll();
    }

    @Override
    public List<User> searchUsersByNameAndEmail(String ch) {
        return userRepo.findByNameContainingIgnoreCaseOrEmailContainingIgnoreCase(ch, ch);
    }

    @Override
    public User getUserById(int id) {
        return userRepo.findById(id).orElse(null);
    }

    @Override
    public List<User> getUsersByRole(String role) {
        return userRepo.findAllByRoleContainsIgnoreCase(role);
    }

    @Transactional
    @Override
    public User updateUser(User editUser) {
        User dbUser = userRepo.findById(editUser.getId()).orElse(null);
        if(dbUser != null){
            if(!editUser.getPassword().trim().isEmpty()){
                String password = passwordEncoder.encode(editUser.getPassword());
                dbUser.setPassword(password);
            }
            if(editUser.getName().trim().isEmpty() || editUser.getEmail().trim().isEmpty()){
                return null;
            }
            dbUser.setName(editUser.getName());
            dbUser.setEmail(editUser.getEmail());
            System.out.println(dbUser);
//            int res = userRepo.updateUser(dbUser.getId(), dbUser.getName(), dbUser.getEmail(), dbUser.getPassword());
            User res = userRepo.save(dbUser);

            if(res != null){
                return dbUser;
            }
        }
        return null;
    }

    //    это для баланса у юзера было
//    @Override
//    public void upBalance(String email, BigDecimal money) {
//        User user = userRepo.findByEmail(email);
//        BigDecimal balance = user.getBalance();
//        BigDecimal result = balance.add(money);
//        user.setBalance(result);
//        userRepo.save(user);
//    }

    @Override
    public Boolean deleteUser(int id) {
        User user = userRepo.findById(id).orElse(null);
        if(user != null){
            userRepo.delete(user);
            return true;
        }
        return false;
    }


}
